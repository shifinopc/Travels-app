<?php

declare(strict_types=1);

namespace Sabberworm\CSS\Value;

abstract class PrimitiveValue extends Value {}
